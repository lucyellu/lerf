int SurfaceTrimmer(int argc, char* argv[]);
